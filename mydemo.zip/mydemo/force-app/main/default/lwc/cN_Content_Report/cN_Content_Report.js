import {
    LightningElement,
    wire,
    api
} from 'lwc';
import CNReportList from '@salesforce/apex/CN_Content_Report.contentReport'
import filtermap from '@salesforce/apex/CN_Content_Report.filterMap'
import contentReport from '@salesforce/apex/CN_Content_Report.insertFilters'
import removedlistview from '@salesforce/apex/CN_Content_Report.removeFilter'
import {
    refreshApex
} from '@salesforce/apex';
import {
    updateRecord
} from 'lightning/uiRecordApi';
import {
    ShowToastEvent
} from 'lightning/platformShowToastEvent';
export default class CN_Content_Report extends LightningElement {
    error;
    casesSpinner = true;
    // @api filtersoqlValue;
    CnDataList = [];
    tempCnDataList = [];
    draftValues = [];
    requiredField = false;
    OperatorMap = [];
    mapOfValues = [];
    fieldMap = [];
    ShowFilterList = [];
    newShowFilterList = [];
    removelogic =[];
    selectedfield = '';
    selectedoperator = '';
    selectedvalue = '';
    selectedLogic = '';
    selectedlistview = '';
    filterlistview;
    datatype;
    input_value = '';
    varBoolean = false;
    varBoolean1 = true;
    listviewrequired = false;

    listviewList = [];

    arefilterVisible = false;
    showfilter = false;
    columns = [
        
        {
            label: 'Owner',
            fieldName: 'OwnerName',
            type: 'Text',
            wrapText: true
        },
        {
            label: 'Title',
            fieldName: 'Title',
            type: 'Text',
            editable: true,
            wrapText: true
        },
        {
            label: 'Tag',
            fieldName: 'TagCsv',
            type: 'Text',
            editable: true,
            wrapText: true
        },
        {
            label: '# of Downloads',
            fieldName: 'countDownload',
            type: 'number',
            wrapText: true,
            cellAttributes: {
                alignment: 'center'
            }
        },
        {
            label: 'Categories',
            fieldName: 'Category',
            type: 'Text',
            wrapText: true
        },
        {
            label: 'Last Modified Date',
            fieldName: 'LastModifiedDate',
            type: 'date-local',
            typeAttributes: {
                month: "2-digit",
                day: "2-digit"
            }
        },
        {
            label: 'Review Date',
            fieldName: 'Review_Date__c',
            editable: true,
            type: 'date-local',
            typeAttributes: {
                month: "2-digit",
                day: "2-digit"
            }
        },

        {
            label: 'Link to content',
            fieldName: 'Downloadlink',
            type: 'url',
            typeAttributes: {
                label: {
                    fieldName: 'Title'
                }
            },
            sortable: true
        },
    ];
    connectedCallback() {
        this.loadData();
    }


    loadData() {
        CNReportList({
                selectlistviewName: this.filterlistview
            })

            .then((data) => {
               
                console.log('dATA========>', data);
                //   this.casesSpinner = false;

                if (this.varBoolean1) {
                    for (var key in data[0].listview) {
                        this.listviewList.push({
                            value: data[0].listview[key],
                            key: key
                        }); //Here we are creating the array to show on UI.
                    }
                }
                console.log('customfilter=====>>>>',JSON.stringify(data[0].customfilter.length) );
                if (data[0].customfilter.length > 0) {
                  
                    this.ShowFilterList = [];
                    this.selectedLogic = '';
                    for (let i = 0; i < data[0].customfilter.length; i++) {
                        // logic = data[0].customfilter[0].Filter_Logic__c;
                        this.ShowFilterList.push({
                            sObjectType: 'Custom_List_View__c',
                             Id : data[0].customfilter[i].Id,
                            Filter_Number__c: data[0].customfilter[i].Filter_Number__c,
                            Field_Api_Name__c: data[0].customfilter[i].Field_Api_Name__c,
                            Operator__c: data[0].customfilter[i].Operator__c,
                            value__c: data[0].customfilter[i].value__c,
                            Data_Type__c: data[0].customfilter[i].Data_Type__c,
                            List_View_Api__c: data[0].customfilter[i].List_View_Api__c,
                            DeveloperName: data[0].customfilter[i].DeveloperName
                        });

                    }
                    this.selectedLogic = data[0].customfilter[0].Filter_Logic__c
                }else{
                    this.ShowFilterList = [];
                    this.selectedLogic ='';
                }
                console.log('======vardata===', data[0].datavar);
               if (data[0].datavar) {
                   // this.CnDataList = [];
                   //if(data != null){
                      this.CnDataList = data.map(row => {
                        let Id = row.cn.Id;
                        let OwnerId = row.cn.OwnerId;
                        let OwnerName = row.cn.Owner.Name;
                        let Category = row.Category;
                        let Title = row.cn.Title;
                        let TagCsv = row.cn.TagCsv;
                        let LastModifiedDate = row.cn.LastModifiedDate;
                        let Review_Date__c = row.cn.Review_Date__c;
                        let countDownload = row.DownloadsCounts;
                        let Downloadlink = `/${row.cn.ContentDocumentId}`;
                        return {
                            ...row,
                            Id,
                            OwnerName,
                            Category,
                            Title,
                            TagCsv,
                            LastModifiedDate,
                            Review_Date__c,
                            Downloadlink,
                            countDownload
                        }
                    });
                  } else {
                    this.CnDataList = [];
                 }

                this.casesSpinner = false;
            })
            .catch((error) => {
                this.casesSpinner = false;
            });

    }

    @wire(filtermap) filtermapFields(result) {
        this.fieldMap = result.data;
        if (result.data) {
         //    console.log('-result.data.cvFieldMap-----------',JSON.stringify(result.data.cvFieldMap));
            for (let key in result.data.cvFieldMap) {
                this.mapOfValues.push({
                    value: result.data.cvFieldMap[key].Label,
                    key: key
                });
            }
            for (let key in result.data.operatorsdMap) {
                this.OperatorMap.push({
                    value: result.data.operatorsdMap[key],
                    key: key
                });
            }
        } else if (result.error) {
            console.log('ObjectInfoerror');
            this.error = error;

        }
    }

    handleSave(event) {

        this.casesSpinner = true;
        const recordInputs = event.detail.draftValues.slice().map(draft => {
            const fields = Object.assign({}, draft);
            return {
                fields
            };
        });
        const promises = recordInputs.map(recordInput => updateRecord(recordInput));
        Promise.all(promises).then(results => {
            this.draftValues = [];
            //  this.casesSpinner = false;
            this.varBoolean = true;
            this.varBoolean1 = false;
            this.loadData();
            this.CnDataList = [];
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Success',
                    message: 'CN updated',
                    variant: 'success'
                })
            );
            // Clear all draft values

            // return refreshApex(this.tempCnDataList);
        }).catch(error => {
            // Handle error
            console.log('error--------', JSON.stringify(error));
            let errorMessage;
            if (error.body.output.errors[0] != null) {
                errorMessage = error.body.output.errors[0].message;
            } else if (error.body.output.fieldErrors.VersionData[0] != null) {
                errorMessage = error.body.output.fieldErrors.VersionData[0].message;
            }
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error',
                    message: errorMessage,
                    variant: 'error'
                })
            );
            this.casesSpinner = false;
        });


    }

    OpenFilter(event) {
       // this.casesSpinner = true;
        if (this.arefilterVisible == false) {
            this.arefilterVisible = true;
            this.showfilter = true;
        } else {
            this.arefilterVisible = false;
        }

    }


    addFilter(event) {

        if (!this.showfilter) {
            this.showfilter = true;

        } else {

            if (this.selectedfield != '' && this.selectedoperator != '' && this.selectedvalue != '') {
                this.showfilter = false;
               let i = this.ShowFilterList.length + 1;

                this.ShowFilterList.push({
                    sObjectType: 'Custom_List_View__c',
                    Id:null,
                    Filter_Number__c: i,
                    Field_Api_Name__c: this.selectedfield,
                    Operator__c: this.selectedoperator,
                    value__c: this.selectedvalue,
                    Data_Type__c: this.datatype,
                    Filter_Logic__c: '',
                    List_View_Api__c: this.selectedLogic+i
                });

                this.selectedfield = '';
                this.selectedoperator = '';
                this.selectedvalue = '';
                this.datatype = '';
                let constlogic;


                for (let j = 0; j < this.ShowFilterList.length; j++) {
                    if (this.ShowFilterList[j].Filter_Number__c > 1) {
                        this.selectedLogic = this.selectedLogic + ' AND ' + this.ShowFilterList[j].Filter_Number__c;
                    } else {
                        this.selectedLogic = this.ShowFilterList[j].Filter_Number__c;
                    }
                }

                // this.selectedLogic = constlogic;
            }

        }

    }

    saveFilter(event) {
        for (let j = 0; j < this.ShowFilterList.length; j++) {
            this.ShowFilterList[j].Filter_Logic__c = this.selectedLogic;
            this.ShowFilterList[j].List_View_Api__c = this.selectedlistview;
        }
      //  console.log('this.selectedlistview ===========>', this.selectedlistview);
        if (this.selectedlistview != '' && this.selectedLogic != '') {
            contentReport({
                    filterList: this.ShowFilterList,
                    customLogic: this.selectedLogic,
                    listview: this.selectedlistview
                })
                .then((result) => {
                    this.varBoolean = true;
                    this.varBoolean1 = false;
                    this.loadData();

                    this.CnDataList = [];
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Success',
                            message: 'Saved',
                            variant: 'success'
                        })
                    );
                    eval("$A.get('e.force:refreshView').fire();");
                })
                .catch((error) => {

                });
        } else {
            this.listviewrequired = true;
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Info',
                    message: 'Please provide List View Name and Custom logic',
                    variant: 'info',
                    mode: 'dismissable'
                })
            );
        }

    }

    changeFieldHandler(event) {
        const field = event.target.value;
        console.log('field--------------',field);
        if (field) {
            this.datatype = this.fieldMap.cvFieldMap[field].Data_Type__c;
        }
        this.selectedfield = field;
    }

    changeOperatorHandler(event) {
        this.selectedoperator = event.target.value;
    }
    inputvalue(event) {
        this.selectedvalue = event.target.value;
    }
    customlogic(event) {
        this.selectedLogic = event.target.value;
    }
    listviewName(event) {
        this.selectedlistview = event.target.value;
    }


    listviewHandler(event) {
        this.casesSpinner = true;
        let selectlist = event.target.value;
        this.selectedlistview = selectlist;
        this.filterlistview = selectlist;
       // this.varBoolean = true;
        this.varBoolean1 = false;

        if (this.arefilterVisible) {
            this.arefilterVisible = false;
        }
        this.loadData();

    }

    colseFilter(event) {
       // this.casesSpinner = true;
        if (this.arefilterVisible) {
            this.arefilterVisible = false;
        }
        if (this.listviewrequired) {
            this.listviewrequired = false;
        }
    }
    deletefilter(event) {
        let targetremove = event.target.dataset.targetId;
      if (this.ShowFilterList.length > 0) {
          this.newShowFilterList = this.ShowFilterList.splice(targetremove - 1, 1);
            
            this.selectedLogic ='';

            for (let p = 0; p < this.ShowFilterList.length; p++) {
                this.ShowFilterList[p].Filter_Number__c = p+1;
                if (this.ShowFilterList[p].Filter_Number__c > 1) {
                    this.selectedLogic = this.selectedLogic + ' AND ' + this.ShowFilterList[p].Filter_Number__c;
                } else {
                    this.selectedLogic = this.ShowFilterList[p].Filter_Number__c;
                }

             }
           //  eval("$A.get('e.force:refreshView').fire();");
             console.log('======ShowFilterList', JSON.stringify(this.ShowFilterList));
        }


    }
    Removelistview(event){
        
        removedlistview({   removelistview:  this.selectedlistview   })
        .then((result) => {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Deleted Success',
                    message: 'Deleted listview',
                    variant: 'success'
                })
            );
            eval("$A.get('e.force:refreshView').fire();");
        }).catch((error) => {
            console.log('==============>',error);
        });
    }

}