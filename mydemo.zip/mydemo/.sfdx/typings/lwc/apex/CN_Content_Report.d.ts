declare module "@salesforce/apex/CN_Content_Report.contentReport" {
  export default function contentReport(param: {selectlistviewName: any}): Promise<any>;
}
declare module "@salesforce/apex/CN_Content_Report.insertFilters" {
  export default function insertFilters(param: {filterList: any, customLogic: any, listview: any}): Promise<any>;
}
declare module "@salesforce/apex/CN_Content_Report.filterMap" {
  export default function filterMap(): Promise<any>;
}
declare module "@salesforce/apex/CN_Content_Report.removeFilter" {
  export default function removeFilter(param: {removelistview: any}): Promise<any>;
}
